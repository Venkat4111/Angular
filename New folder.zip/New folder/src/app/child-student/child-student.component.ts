import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-child-student',
  templateUrl: './child-student.component.html',
  styleUrls: ['./child-student.component.css']
})
export class ChildStudentComponent implements OnInit {
  @Input()
  students: any[];
  @Input()
  course: any[];
  sCount = 0;
  cStudents: any[];
  cCourse: any[];
  constructor() {
    this.cCourse = this.course;
    this.cStudents = this.students;
    /*this.sCount = this.cStudents.length;*/
  }

  ngOnInit() {
  }

}

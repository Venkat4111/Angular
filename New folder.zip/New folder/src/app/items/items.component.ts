import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  constructor() { }
  items: string[];
  heading: string;
  fruits = ['Apple', 'Banana'];
  veg = ['tomato', 'bottle guard'];
  ngOnInit() {
  }
  display(p) {
    // tslint:disable-next-line:triple-equals
    if (p == 'f') {
      this.heading = 'List of Fruits';
      this.items = this.fruits;
      // tslint:disable-next-line:triple-equals
    } else if (p == 'v') {
      this.items = this.veg;
      this.heading = 'List of Vegetable';
    }
  }
}

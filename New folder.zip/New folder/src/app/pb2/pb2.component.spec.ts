import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Pb2Component } from './pb2.component';

describe('Pb2Component', () => {
  let component: Pb2Component;
  let fixture: ComponentFixture<Pb2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Pb2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Pb2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

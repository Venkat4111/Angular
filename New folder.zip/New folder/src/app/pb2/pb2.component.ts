import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pb2',
  templateUrl: './pb2.component.html',
  styleUrls: ['./pb2.component.css']
})
export class Pb2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

import { Component, Output } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  /*  display(x) {
      // tslint:disable-next-line:prefer-const
      let d = new Date();
      // tslint:disable-next-line:triple-equals
      if (x == 'date') {
        return d.getDate();
      // tslint:disable-next-line:triple-equals
      } else if (x == 'time') {
        return d.getHours();
             }
    }*/
  // tslint:disable-next-line:whitespace
  n1 = 0;

  direction = 'East';
  msg: any = {};
  sayHello() {
    this.msg = 'Hi';
    this.direction = 'North';
  }
  msgToChild() {
    return 'message from Parent';
  }
  display(e) {
    console.log(e.value);
    this.msg = e.value;
  }

}

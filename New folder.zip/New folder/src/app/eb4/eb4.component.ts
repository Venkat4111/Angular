import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb4',
  templateUrl: './eb4.component.html',
  styleUrls: ['./eb4.component.css']
})
export class Eb4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

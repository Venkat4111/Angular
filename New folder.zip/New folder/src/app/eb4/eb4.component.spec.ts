import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Eb4Component } from './eb4.component';

describe('Eb4Component', () => {
  let component: Eb4Component;
  let fixture: ComponentFixture<Eb4Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Eb4Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Eb4Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent-student',
  templateUrl: './parent-student.component.html',
  styleUrls: ['./parent-student.component.css']
})
export class ParentStudentComponent implements OnInit {


  students: any[];
  sCount: number;
  course: any[];
  constructor() {
    this.course = ['java', 'angular', 'net', 'react'];
    this.students = [
      { id: 1, name: 'abc1', skill: this.course[0] },
      { id: 2, name: 'abc2', skill: this.course[0] },
      { id: 3, name: 'abc3', skill: this.course[1] },
      { id: 4, name: 'abc4', skill: this.course[1] },
      { id: 5, name: 'abc5', skill: this.course[2] },
      { id: 6, name: 'abc6', skill: this.course[2] },
      { id: 7, name: 'abc7', skill: this.course[3] },
      { id: 8, name: 'abc8', skill: this.course[3] },
      { id: 9, name: 'abc9', skill: this.course[1] },
      { id: 10, name: 'abc10', skill: this.course[2] },
      { id: 11, name: 'abc11', skill: this.course[0] },
      { id: 12, name: 'abc12', skill: this.course[0] },
    ];

  }
  msgToChild() {
    return this.students;
  }

  msgToChild1() {
    return this.course;
  }

  ngOnInit() {
  }

}

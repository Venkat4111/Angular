import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.css']
})
export class EmployeesComponent implements OnInit {
  employees: any[];
  x = {};
  showme = false;
  constructor() {
    this.employees = [
      { id: 1, name: 'abc1', job: 'admin', salary: 1000 },
      { id: 2, name: 'abc2', job: 'engineer', salary: 2000 },
      { id: 3, name: 'abc3', job: 'manager', salary: 3000 },
      { id: 4, name: 'abc4', job: 'director', salary: 4000 },
      { id: 5, name: 'abc5', job: 'president', salary: 5000 },
    ];
  }

  search(i) {
    this.showme = true;
    this.x = JSON.parse(JSON.stringify(this.employees[i]));
  }
  delete(i) {
    this.employees.splice(i, 1);

  }
  addRow() {
    this.employees.push(this.x);

  }
  ngOnInit() {
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb1',
  templateUrl: './eb1.component.html',
  styleUrls: ['./eb1.component.css']
})
export class Eb1Component implements OnInit {
  n1 = 0;
  direction = 'East';
  msg = '';
  sayHello() {
    this.msg = 'Hi';
    this.direction = 'North';
  }
  constructor() { }

  ngOnInit() {
  }

}

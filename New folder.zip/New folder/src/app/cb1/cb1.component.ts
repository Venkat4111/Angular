import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cb1',
  templateUrl: './cb1.component.html',
  styleUrls: ['./cb1.component.css']
})
export class Cb1Component implements OnInit {

  constructor() { }
  heading = 'heading2';
  ngOnInit() {
  }

}

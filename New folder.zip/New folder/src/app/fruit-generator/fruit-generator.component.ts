import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fruit-generator',
  templateUrl: './fruit-generator.component.html',
  styleUrls: ['./fruit-generator.component.css']
})
export class FruitGeneratorComponent implements OnInit {

  constructor() { }
  fruits = ['Apple', 'Mango', 'Grape'];
  ngOnInit() {
  }

}

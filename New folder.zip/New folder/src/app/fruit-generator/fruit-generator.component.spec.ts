import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FruitGeneratorComponent } from './fruit-generator.component';

describe('FruitGeneratorComponent', () => {
  let component: FruitGeneratorComponent;
  let fixture: ComponentFixture<FruitGeneratorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FruitGeneratorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FruitGeneratorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pb1',
  templateUrl: './pb1.component.html',
  styleUrls: ['./pb1.component.css']
})
export class Pb1Component implements OnInit {

  constructor() { }
  path = './assets/IMG.jpg';
  ngOnInit() {
  }

}

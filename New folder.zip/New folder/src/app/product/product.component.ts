import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Employee } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  arr: Employee[];
  emp: Employee;
  testmsg2;
  constructor(private pr: ProductService) {
  }
  getData() {
    this.pr.getData().subscribe(res => this.arr = res);
  }

  getEmp(id) {
    this.pr.getEmp(id).subscribe(res => this.emp = res);
  }

  ngOnInit() {
  }

}

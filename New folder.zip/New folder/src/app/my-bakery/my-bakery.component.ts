import { Component, OnInit } from '@angular/core';
import { BisuitFactoryService } from '../bisuit-factory.service';
@Component({
  selector: 'app-my-bakery',
  templateUrl: './my-bakery.component.html',
  styleUrls: ['./my-bakery.component.css']
})
export class MyBakeryComponent implements OnInit {
  bis;
  constructor(public mf: BisuitFactoryService) {

  }

  showBis() {
    this.bis = this.mf.bis;
  }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyBakeryComponent } from './my-bakery.component';

describe('MyBakeryComponent', () => {
  let component: MyBakeryComponent;
  let fixture: ComponentFixture<MyBakeryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyBakeryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyBakeryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

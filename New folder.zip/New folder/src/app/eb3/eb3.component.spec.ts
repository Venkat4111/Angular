import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Eb3Component } from './eb3.component';

describe('Eb3Component', () => {
  let component: Eb3Component;
  let fixture: ComponentFixture<Eb3Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Eb3Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Eb3Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

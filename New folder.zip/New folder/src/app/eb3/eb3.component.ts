import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb3',
  templateUrl: './eb3.component.html',
  styleUrls: ['./eb3.component.css']
})
export class Eb3Component implements OnInit {
  a = 0;
  b = 0;
  c = 0;
  display() {
    this.c = this.a + this.b;

  }
  constructor() { }

  ngOnInit() {
  }

}

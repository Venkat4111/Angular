import { TestBed, inject } from '@angular/core/testing';

import { BisuitFactoryService } from './bisuit-factory.service';

describe('BisuitFactoryService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BisuitFactoryService]
    });
  });

  it('should be created', inject([BisuitFactoryService], (service: BisuitFactoryService) => {
    expect(service).toBeTruthy();
  }));
});

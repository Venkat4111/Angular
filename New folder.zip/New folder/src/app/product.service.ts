import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductService {

  testmsg: string;
  url = 'http://localhost:3000/employees';
  data: any = {};
  constructor(private _http: HttpClient) {
    /*  this.products = [{ id: 14566, name: 'xyz' }
        , { id: 1234, name: 'abc' }];*/

  }
  products: Employee[];
  getDataFromAPI(): Observable<Employee[]> {
    return this._http.get<Employee[]>(this.url);
  }

  getData() {
    return this.getDataFromAPI();
  }

  getEmpAPI(id) {
    return this._http.get<Employee>(`${this.url}/${id}`);
  }
  getEmp(id) {
    return this.getEmpAPI(id);
  }
}

export class Employee {
  id: number;
  name: string;
}

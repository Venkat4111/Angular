import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb2',
  templateUrl: './eb2.component.html',
  styleUrls: ['./eb2.component.css']
})
export class Eb2Component implements OnInit {
  n2 = '';
  direction = 'East';
  msg = '';
  display() {
    this.msg = `Hi  ${this.n2}`;

  }

  constructor() { }

  ngOnInit() {
  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Eb2Component } from './eb2.component';

describe('Eb2Component', () => {
  let component: Eb2Component;
  let fixture: ComponentFixture<Eb2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Eb2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Eb2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

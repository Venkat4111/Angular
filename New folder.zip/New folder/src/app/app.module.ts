import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TestComponent } from './test/test.component';
import { Test2Component } from './test2/test2.component';
import { FormsModule } from '@angular/forms';
import { Eb1Component } from './eb1/eb1.component';
import { Eb2Component } from './eb2/eb2.component';
import { Eb3Component } from './eb3/eb3.component';
import { Eb4Component } from './eb4/eb4.component';
import { Pb1Component } from './pb1/pb1.component';
import { Pb2Component } from './pb2/pb2.component';
import { Cb1Component } from './cb1/cb1.component';
import { Sb1Component } from './sb1/sb1.component';
import { EbExamplesComponent } from './eb-examples/eb-examples.component';
import { FruitGeneratorComponent } from './fruit-generator/fruit-generator.component';
import { ItemsComponent } from './items/items.component';
import { EmployeesComponent } from './employees/employees.component';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { ParentStudentComponent } from './parent-student/parent-student.component';
import { ChildStudentComponent } from './child-student/child-student.component';
import { MyBakeryComponent } from './my-bakery/my-bakery.component';
import { BisuitFactoryService } from './bisuit-factory.service';
import { ProductComponent } from './product/product.component';
import { ProductService } from './product.service';
import { MyPipePipe } from './my-pipe.pipe';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AboutComponent } from './about/about.component';
import { HelpComponent } from './help/help.component';
import { ErrorComponent } from './error/error.component';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LogoutComponent } from './logout/logout.component';


@NgModule({
  declarations: [
    AppComponent,
    TestComponent,
    Test2Component,
    Eb1Component,
    Eb2Component,
    Eb3Component,
    Eb4Component,
    Pb1Component,
    Pb2Component,
    Cb1Component,
    Sb1Component,
    EbExamplesComponent,
    FruitGeneratorComponent,
    ItemsComponent,
    EmployeesComponent,
    ParentComponent,
    ChildComponent,
    ParentStudentComponent,
    ChildStudentComponent,
    MyBakeryComponent,
    ProductComponent,
    MyPipePipe,
    AboutComponent,
    HelpComponent,
    ErrorComponent,
    LoginComponent,
    DashboardComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,


  ],
  providers: [BisuitFactoryService, ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }

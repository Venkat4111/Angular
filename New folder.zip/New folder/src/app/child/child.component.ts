import { Component, OnInit, Input } from '@angular/core';
import { Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {

  constructor() { }
  t1: string;
  @Input()
  pData: string;

  @Output()
  childEvent: any = new EventEmitter<string>();
  msg: string;
  display() {
    this.msg = this.pData;
  }
  ngOnInit() {
  }

  sendData() {
    this.childEvent.emit(this.t1);
  }

}

import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-eb-examples',
  templateUrl: './eb-examples.component.html',
  styleUrls: ['./eb-examples.component.css']
})
export class EbExamplesComponent implements OnInit {
  ex1;
  ex2;
  ex3;
  ex4;
  ex5;
  ex6;

  constructor() { }

  ngOnInit() {
  }

}

import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'myPipe'
})
export class MyPipePipe implements PipeTransform {

  transform(name: any, id?: any): any {

    console.log('inside2');
    // tslint:disable-next-line:triple-equals
    if (id == 14566) {
      console.log('inside');
      return 'First one ' + name;
      // tslint:disable-next-line:triple-equals
    } else if (id == 1234) {
      return 'Second one ' + name;
    }
  }

}

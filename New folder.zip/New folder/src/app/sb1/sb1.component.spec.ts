import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Sb1Component } from './sb1.component';

describe('Sb1Component', () => {
  let component: Sb1Component;
  let fixture: ComponentFixture<Sb1Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Sb1Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Sb1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

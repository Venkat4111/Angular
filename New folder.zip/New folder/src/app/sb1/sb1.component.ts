import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sb1',
  templateUrl: './sb1.component.html',
  styleUrls: ['./sb1.component.css']
})
export class Sb1Component implements OnInit {

  constructor() { }
  s1 = { 'color': 'green' };
  s2 = { 'text-decoration': 'underline' };
  ngOnInit() {
  }

}
